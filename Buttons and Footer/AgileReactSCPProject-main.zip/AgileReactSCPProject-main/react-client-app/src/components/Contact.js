import React from 'react';
import Footer from './footer';
import ButtonComponent from './ButtonComponent';
 
function Contact (){
    return <div>
    <h1>Contact</h1>
    <ButtonComponent />
    <Footer />
  </div>
}
 
export default Contact;