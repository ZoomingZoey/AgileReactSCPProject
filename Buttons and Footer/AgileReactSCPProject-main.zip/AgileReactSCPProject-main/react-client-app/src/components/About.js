import React from 'react';
import Footer from './footer';
import ButtonComponent from './ButtonComponent';
 
function About (){
    return <div>
    <h1>About</h1>
    <ButtonComponent />
    <Footer />
  </div>
}
 
export default About;