# AgileReactSCPProject
A SCP themed web app built using React.js, MongoDB and Express.js using the agile scrum software development methodology.

## Team members
- Zach Coley
- Alice Watson-Howcroft
- Kim Parker
